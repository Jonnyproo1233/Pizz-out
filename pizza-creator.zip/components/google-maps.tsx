"use client"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MapPin, Search } from "lucide-react"

interface GoogleMapsSelectorProps {
  onLocationSelect: (location: { lat: number; lng: number }) => void
  selectedLocation: { lat: number; lng: number } | null
}

export function GoogleMapsSelector({ onLocationSelect, selectedLocation }: GoogleMapsSelectorProps) {
  const [address, setAddress] = useState("")
  const [isSearching, setIsSearching] = useState(false)

  // Simulación de búsqueda de dirección (en producción usarías Google Places API)
  const searchAddress = useCallback(async () => {
    if (!address.trim()) return

    setIsSearching(true)

    // Simulación de delay de API
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Coordenadas simuladas (en producción usarías geocoding real)
    const mockLocation = {
      lat: 19.4326 + (Math.random() - 0.5) * 0.1,
      lng: -99.1332 + (Math.random() - 0.5) * 0.1,
    }

    onLocationSelect(mockLocation)
    setIsSearching(false)
  }, [address, onLocationSelect])

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          onLocationSelect({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          })
        },
        (error) => {
          console.error("Error obteniendo ubicación:", error)
          // Fallback a ubicación por defecto (Ciudad de México)
          onLocationSelect({
            lat: 19.4326,
            lng: -99.1332,
          })
        },
      )
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="Buscar dirección..."
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className="pl-10"
            onKeyPress={(e) => e.key === "Enter" && searchAddress()}
          />
        </div>
        <Button onClick={searchAddress} disabled={isSearching || !address.trim()} variant="outline">
          {isSearching ? "Buscando..." : "Buscar"}
        </Button>
      </div>

      <Button onClick={getCurrentLocation} variant="outline" className="w-full bg-transparent">
        <MapPin className="h-4 w-4 mr-2" />
        Usar mi ubicación actual
      </Button>

      {/* Mapa simulado */}
      <div className="h-64 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center relative overflow-hidden">
        {selectedLocation ? (
          <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-4xl mb-2">📍</div>
                <p className="text-sm font-medium">Ubicación seleccionada</p>
                <p className="text-xs text-gray-600">
                  Lat: {selectedLocation.lat.toFixed(4)}, Lng: {selectedLocation.lng.toFixed(4)}
                </p>
              </div>
            </div>
            {/* Simulación de calles */}
            <div className="absolute top-1/3 left-0 right-0 h-1 bg-gray-400 opacity-30"></div>
            <div className="absolute top-2/3 left-0 right-0 h-1 bg-gray-400 opacity-30"></div>
            <div className="absolute top-0 bottom-0 left-1/3 w-1 bg-gray-400 opacity-30"></div>
            <div className="absolute top-0 bottom-0 left-2/3 w-1 bg-gray-400 opacity-30"></div>
          </div>
        ) : (
          <div className="text-center text-gray-500">
            <MapPin className="h-8 w-8 mx-auto mb-2" />
            <p className="text-sm">Selecciona tu ubicación</p>
            <p className="text-xs">Busca una dirección o usa tu ubicación actual</p>
          </div>
        )}
      </div>

      {selectedLocation && (
        <div className="p-3 bg-green-50 rounded-lg border border-green-200">
          <p className="text-sm text-green-800 flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Ubicación confirmada para entrega
          </p>
        </div>
      )}
    </div>
  )
}
