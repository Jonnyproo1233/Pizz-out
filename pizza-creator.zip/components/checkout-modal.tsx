"use client"

import { useState } from "react"
import type { PizzaIngredientUnit } from "./pizza-builder"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { GoogleMapsSelector } from "./google-maps"
import { CreditCard, MapPin, User, Clock, CheckCircle } from "lucide-react"

interface OrderSummary {
  ingredients: (PizzaIngredientUnit & { quantity: number })[]
  size: "small" | "medium" | "large"
  total: number
  basePrice: number
}

interface CheckoutModalProps {
  isOpen: boolean
  onClose: () => void
  orderSummary: OrderSummary
}

export function CheckoutModal({ isOpen, onClose, orderSummary }: CheckoutModalProps) {
  const [step, setStep] = useState<"details" | "payment" | "confirmation">("details")
  const [paymentMethod, setPaymentMethod] = useState<"card" | "cash">("card")
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    address: "",
    notes: "",
  })
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [orderNumber, setOrderNumber] = useState("")

  const handleSubmitOrder = () => {
    // Generar número de orden
    const orderNum = `PZ${Date.now().toString().slice(-6)}`
    setOrderNumber(orderNum)
    setStep("confirmation")

    // Aquí integrarías con tu backend para procesar el pedido
    console.log("Orden procesada:", {
      orderNumber: orderNum,
      customer: customerInfo,
      location: selectedLocation,
      paymentMethod,
      order: orderSummary,
    })
  }

  const resetAndClose = () => {
    setStep("details")
    setCustomerInfo({ name: "", phone: "", address: "", notes: "" })
    setSelectedLocation(null)
    setOrderNumber("")
    onClose()
  }

  const estimatedDeliveryTime = () => {
    const now = new Date()
    now.setMinutes(now.getMinutes() + 30 + Math.floor(Math.random() * 20))
    return now.toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" })
  }

  return (
    <Dialog open={isOpen} onOpenChange={resetAndClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === "details" && (
              <>
                <User className="h-5 w-5" /> Información de Entrega
              </>
            )}
            {step === "payment" && (
              <>
                <CreditCard className="h-5 w-5" /> Método de Pago
              </>
            )}
            {step === "confirmation" && (
              <>
                <CheckCircle className="h-5 w-5 text-green-600" /> ¡Pedido Confirmado!
              </>
            )}
          </DialogTitle>
        </DialogHeader>

        {step === "details" && (
          <div className="space-y-6">
            {/* Resumen del pedido */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Pizza {orderSummary.size} (base)</span>
                    <span>${orderSummary.basePrice.toFixed(2)}</span>
                  </div>
                  {orderSummary.ingredients.map((ingredient) => (
                    <div key={ingredient.ingredientId} className="flex justify-between">
                      <span>
                        {ingredient.image} {ingredient.name} x{ingredient.quantity}
                      </span>
                      <span>${(ingredient.price * ingredient.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 flex justify-between font-bold">
                    <span>Total</span>
                    <span>${orderSummary.total.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Información del cliente */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nombre completo *</Label>
                <Input
                  id="name"
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, name: e.target.value }))}
                  placeholder="Tu nombre"
                />
              </div>
              <div>
                <Label htmlFor="phone">Teléfono *</Label>
                <Input
                  id="phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo((prev) => ({ ...prev, phone: e.target.value }))}
                  placeholder="+1 234 567 8900"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Dirección de entrega *</Label>
              <Input
                id="address"
                value={customerInfo.address}
                onChange={(e) => setCustomerInfo((prev) => ({ ...prev, address: e.target.value }))}
                placeholder="Calle, número, colonia, ciudad"
              />
            </div>

            {/* Selector de ubicación */}
            <div>
              <Label className="flex items-center gap-2 mb-2">
                <MapPin className="h-4 w-4" />
                Selecciona tu ubicación en el mapa
              </Label>
              <GoogleMapsSelector onLocationSelect={setSelectedLocation} selectedLocation={selectedLocation} />
            </div>

            <div>
              <Label htmlFor="notes">Notas adicionales (opcional)</Label>
              <Textarea
                id="notes"
                value={customerInfo.notes}
                onChange={(e) => setCustomerInfo((prev) => ({ ...prev, notes: e.target.value }))}
                placeholder="Instrucciones especiales, referencias del domicilio, etc."
              />
            </div>

            <Button
              className="w-full"
              onClick={() => setStep("payment")}
              disabled={!customerInfo.name || !customerInfo.phone || !customerInfo.address || !selectedLocation}
            >
              Continuar al Pago
            </Button>
          </div>
        )}

        {step === "payment" && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Método de Pago</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={(value: "card" | "cash") => setPaymentMethod(value)}>
                  <div className="flex items-center space-x-2 p-4 border rounded-lg">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card" className="flex items-center gap-2 cursor-pointer">
                      <CreditCard className="h-4 w-4" />
                      Pagar con tarjeta (en línea)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 p-4 border rounded-lg">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash" className="flex items-center gap-2 cursor-pointer">
                      💵 Pagar en efectivo (contra entrega)
                    </Label>
                  </div>
                </RadioGroup>

                {paymentMethod === "card" && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-800">
                      Serás redirigido a nuestro procesador de pagos seguro para completar la transacción.
                    </p>
                  </div>
                )}

                {paymentMethod === "cash" && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg">
                    <p className="text-sm text-green-800">
                      Paga en efectivo cuando recibas tu pedido. Asegúrate de tener el monto exacto: $
                      {orderSummary.total.toFixed(2)}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep("details")} className="flex-1">
                Volver
              </Button>
              <Button onClick={handleSubmitOrder} className="flex-1">
                {paymentMethod === "card" ? "Proceder al Pago" : "Confirmar Pedido"}
              </Button>
            </div>
          </div>
        )}

        {step === "confirmation" && (
          <div className="text-center space-y-6">
            <div className="text-6xl">🍕</div>
            <div>
              <h3 className="text-2xl font-bold text-green-600 mb-2">¡Pedido Confirmado!</h3>
              <p className="text-gray-600">Tu pizza está siendo preparada con amor</p>
            </div>

            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Número de pedido:</span>
                    <span className="font-bold text-lg">#{orderNumber}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Total pagado:</span>
                    <span className="font-bold text-lg">${orderSummary.total.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Método de pago:</span>
                    <span>{paymentMethod === "card" ? "Tarjeta" : "Efectivo"}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Tiempo estimado:
                    </span>
                    <span className="font-bold text-green-600">{estimatedDeliveryTime()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="p-4 bg-yellow-50 rounded-lg">
              <p className="text-sm text-yellow-800">
                📱 Te enviaremos actualizaciones por WhatsApp al {customerInfo.phone}
              </p>
            </div>

            <Button onClick={resetAndClose} className="w-full">
              Hacer Otro Pedido
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
