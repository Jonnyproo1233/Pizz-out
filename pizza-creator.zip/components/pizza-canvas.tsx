"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import type { PizzaIngredientUnit } from "./pizza-builder"
import { X, RotateCw, RotateCcw } from "lucide-react"

interface PizzaCanvasProps {
  ingredientUnits: PizzaIngredientUnit[]
  size: "small" | "medium" | "large"
  onIngredientMove: (id: string, position: { x: number; y: number }) => void
  onIngredientRotate: (id: string, rotation: number) => void
  onRemoveUnit: (id: string) => void
}

export function PizzaCanvas({
  ingredientUnits,
  size,
  onIngredientMove,
  onIngredientRotate,
  onRemoveUnit,
}: PizzaCanvasProps) {
  const [draggedIngredient, setDraggedIngredient] = useState<string | null>(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [hoveredUnit, setHoveredUnit] = useState<string | null>(null)
  const [selectedUnit, setSelectedUnit] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const pizzaRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLDivElement>(null)

  const sizeClasses = {
    small: "w-48 h-48",
    medium: "w-64 h-64",
    large: "w-80 h-80",
  }

  const isFullCoverageIngredient = (ingredientId: string) => {
    return ["mozzarella", "parmesano", "cheddar", "salsa-tomate"].includes(ingredientId)
  }

  const isRotatableIngredient = (ingredientId: string) => {
    return ["jamon", "salchicha", "pollo", "champinones", "aceitunas"].includes(ingredientId)
  }

  // Efecto para manejar clics fuera de los ingredientes
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      // Si el clic fue dentro de un botón de control, no hacemos nada
      if ((e.target as HTMLElement).closest(".ingredient-control-button")) {
        return
      }

      // Si el clic fue dentro de un ingrediente, ya se manejará en su propio onClick
      if ((e.target as HTMLElement).closest(".ingredient-item")) {
        return
      }

      // Si llegamos aquí, el clic fue fuera de cualquier ingrediente o botón
      setSelectedUnit(null)
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
    }
  }, [])

  const handleMouseDown = (e: React.MouseEvent, unitId: string) => {
    // Si el clic fue en un botón de control, no iniciamos arrastre
    if ((e.target as HTMLElement).closest(".ingredient-control-button")) {
      return
    }

    e.preventDefault()
    const unit = ingredientUnits.find((u) => u.id === unitId)
    if (!unit || !pizzaRef.current) return

    // Seleccionar el ingrediente
    setSelectedUnit(unitId)

    const rect = pizzaRef.current.getBoundingClientRect()

    // Calcular offset del mouse respecto al centro del ingrediente
    const ingredientX = (unit.position.x / 100) * rect.width
    const ingredientY = (unit.position.y / 100) * rect.height

    setDragOffset({
      x: e.clientX - rect.left - ingredientX,
      y: e.clientY - rect.top - ingredientY,
    })

    setDraggedIngredient(unitId)
    setIsDragging(true)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggedIngredient || !pizzaRef.current || !isDragging) return

    const rect = pizzaRef.current.getBoundingClientRect()

    // Calcular nueva posición
    const newX = e.clientX - rect.left - dragOffset.x
    const newY = e.clientY - rect.top - dragOffset.y

    // Convertir a porcentajes
    const xPercent = (newX / rect.width) * 100
    const yPercent = (newY / rect.height) * 100

    // Limitar dentro del círculo de la pizza
    const centerX = 50
    const centerY = 50
    const radius = 45 // Radio del círculo en porcentaje

    const distanceFromCenter = Math.sqrt(Math.pow(xPercent - centerX, 2) + Math.pow(yPercent - centerY, 2))

    let finalX = xPercent
    let finalY = yPercent

    // Si está fuera del círculo, proyectar al borde
    if (distanceFromCenter > radius) {
      const angle = Math.atan2(yPercent - centerY, xPercent - centerX)
      finalX = centerX + Math.cos(angle) * radius
      finalY = centerY + Math.sin(angle) * radius
    }

    // Asegurar que esté dentro de los límites (0-100%)
    finalX = Math.max(5, Math.min(95, finalX))
    finalY = Math.max(5, Math.min(95, finalY))

    onIngredientMove(draggedIngredient, { x: finalX, y: finalY })
  }

  const handleMouseUp = () => {
    setDraggedIngredient(null)
    setDragOffset({ x: 0, y: 0 })
    setIsDragging(false)
  }

  const handleRotate = (unitId: string, direction: "clockwise" | "counterclockwise") => {
    const unit = ingredientUnits.find((u) => u.id === unitId)
    if (!unit || !isRotatableIngredient(unit.ingredientId)) return

    const rotationDelta = direction === "clockwise" ? 45 : -45
    const newRotation = (unit.rotation + rotationDelta + 360) % 360
    onIngredientRotate(unitId, newRotation)
  }

  // Agrupar ingredientes por tipo para capas completas
  const fullCoverageIngredients = ingredientUnits.reduce(
    (acc, unit) => {
      if (isFullCoverageIngredient(unit.ingredientId)) {
        if (!acc[unit.ingredientId]) {
          acc[unit.ingredientId] = {
            ...unit,
            quantity: 1,
          }
        } else {
          acc[unit.ingredientId].quantity += 1
        }
      }
      return acc
    },
    {} as Record<string, PizzaIngredientUnit & { quantity: number }>,
  )

  return (
    <div className="flex justify-center" ref={canvasRef}>
      <div
        ref={pizzaRef}
        className={`relative ${sizeClasses[size]} mx-auto bg-gradient-to-br from-yellow-200 to-orange-300 rounded-full border-8 border-yellow-600 shadow-lg overflow-hidden cursor-crosshair select-none`}
        style={{
          background: `
            radial-gradient(circle at 30% 30%, #FFF8DC 0%, #F4A460 40%, #D2691E 100%),
            radial-gradient(circle at 70% 70%, rgba(255,255,255,0.3) 0%, transparent 50%)
          `,
        }}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        {/* Base de queso */}
        <div className="absolute inset-2 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-full opacity-80" />

        {/* Capas que cubren toda la pizza (quesos y salsa) */}
        {Object.values(fullCoverageIngredients).map((ingredient) => (
          <div
            key={`full-layer-${ingredient.ingredientId}`}
            className="absolute inset-4 rounded-full pointer-events-none"
            style={{
              backgroundColor: ingredient.color,
              opacity:
                ingredient.ingredientId === "salsa-tomate"
                  ? Math.min(0.4 + ingredient.quantity * 0.1, 0.7)
                  : Math.min(0.3 + ingredient.quantity * 0.15, 0.8),
              mixBlendMode: ingredient.ingredientId === "salsa-tomate" ? "normal" : "multiply",
              zIndex: ingredient.ingredientId === "salsa-tomate" ? 3 : 5,
            }}
            title={`${ingredient.name} - ${ingredient.quantity} porción${ingredient.quantity > 1 ? "es" : ""}`}
          />
        ))}

        {/* Líneas guía sutiles para ayudar con el posicionamiento */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/2 left-2 right-2 h-px bg-white opacity-10" />
          <div className="absolute left-1/2 top-2 bottom-2 w-px bg-white opacity-10" />
        </div>

        {/* Ingredientes individuales */}
        {ingredientUnits
          .filter((unit) => !isFullCoverageIngredient(unit.ingredientId))
          .map((unit) => {
            const isBeingDragged = draggedIngredient === unit.id && isDragging
            const isHovered = hoveredUnit === unit.id
            const isSelected = selectedUnit === unit.id
            const isRotatable = isRotatableIngredient(unit.ingredientId)
            const showControls = isSelected || (isHovered && !isDragging)

            return (
              <div
                key={unit.id}
                className={`absolute cursor-grab active:cursor-grabbing transition-all duration-150 ingredient-item ${
                  isBeingDragged ? "scale-110 z-50 shadow-lg" : isSelected ? "z-40" : "hover:scale-105 hover:z-40 z-30"
                }`}
                style={{
                  left: `${unit.position.x}%`,
                  top: `${unit.position.y}%`,
                  transform: "translate(-50%, -50%)",
                }}
                onMouseDown={(e) => handleMouseDown(e, unit.id)}
                onMouseEnter={() => setHoveredUnit(unit.id)}
                onMouseLeave={() => setHoveredUnit(null)}
                onClick={(e) => {
                  // Si el clic fue en un botón de control, no seleccionamos el ingrediente
                  if ((e.target as HTMLElement).closest(".ingredient-control-button")) {
                    return
                  }
                  setSelectedUnit(unit.id)
                }}
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-lg shadow-md border-2 transition-all duration-300 text-slate-400 ${
                    isSelected ? "border-blue-400 ring-2 ring-blue-400 ring-opacity-50" : "border-white"
                  } ${isRotatable ? "ring-1 ring-yellow-300" : ""}`}
                  style={{
                    backgroundColor: unit.color,
                    boxShadow: isBeingDragged ? "0 8px 25px rgba(0,0,0,0.3)" : "0 2px 8px rgba(0,0,0,0.2)",
                    transform: `rotate(${unit.rotation}deg)`,
                  }}
                  title={`${unit.name} - Arrastra para mover${isRotatable ? " | Rotable" : ""}`}
                >
                  {unit.image}
                </div>

                {/* Controles que aparecen al hacer hover o seleccionar */}
                {showControls && (
                  <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 flex items-center gap-1">
                    {/* Botones de rotación para ingredientes rotables */}
                    {isRotatable && (
                      <>
                        <button
                          className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-md hover:bg-blue-600 transition-colors ingredient-control-button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleRotate(unit.id, "counterclockwise")
                          }}
                          title="Rotar hacia la izquierda"
                        >
                          <RotateCcw className="w-3 h-3" />
                        </button>
                        <button
                          className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-md hover:bg-blue-600 transition-colors ingredient-control-button"
                          onClick={(e) => {
                            e.stopPropagation()
                            handleRotate(unit.id, "clockwise")
                          }}
                          title="Rotar hacia la derecha"
                        >
                          <RotateCw className="w-3 h-3" />
                        </button>
                      </>
                    )}

                    {/* Botón de eliminar */}
                    <button
                      className="bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center shadow-md hover:bg-red-600 transition-colors ingredient-control-button"
                      onClick={(e) => {
                        e.stopPropagation()
                        onRemoveUnit(unit.id)
                        setSelectedUnit(null)
                      }}
                      title="Eliminar ingrediente"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}

                {/* Indicador de rotación actual para ingredientes rotables */}
                {isRotatable && showControls && (
                  <div className="absolute -bottom-6 left-1/2 transform -translate-x-1/2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                    {unit.rotation}°
                  </div>
                )}
              </div>
            )
          })}

        {/* Mensaje cuando no hay ingredientes */}
        {ingredientUnits.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center text-gray-600">
              <div className="text-4xl mb-2">🍕</div>
              <p className="text-sm font-medium">Agrega ingredientes</p>
              <p className="text-xs">para personalizar tu pizza</p>
              <p className="text-xs mt-1 opacity-75">¡Podrás arrastrarlos donde quieras!</p>
            </div>
          </div>
        )}

        {/* Indicador de zona de arrastre cuando se está arrastrando */}
        {draggedIngredient && isDragging && (
          <div className="absolute inset-2 border-2 border-dashed border-blue-400 rounded-full opacity-50 pointer-events-none animate-pulse" />
        )}
      </div>

      {/* Instrucciones de uso */}
      {ingredientUnits.length > 0 && (
        <div className="absolute -bottom-12 left-1/2 transform -translate-x-1/2 text-xs text-gray-500 text-center max-w-xs">
          <p>💡 Haz clic en un ingrediente para seleccionarlo y ver sus controles</p>
          <p>🔄 Usa los botones azules para rotar ingredientes especiales</p>
          <p>❌ Usa el botón rojo para eliminar</p>
        </div>
      )}
    </div>
  )
}
