"use client"

import { useState } from "react"
import type { Ingredient, PizzaIngredientUnit } from "./pizza-builder"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Plus, Trash2 } from "lucide-react"

interface IngredientsPanelProps {
  ingredients: Ingredient[]
  onAddIngredient: (ingredient: Ingredient) => void
  onRemoveIngredient: (ingredientId: string) => void
  selectedIngredients: (PizzaIngredientUnit & { quantity: number })[]
}

export function IngredientsPanel({
  ingredients,
  onAddIngredient,
  onRemoveIngredient,
  selectedIngredients,
}: IngredientsPanelProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  const categories = ["all", ...Array.from(new Set(ingredients.map((i) => i.category)))]

  const filteredIngredients = ingredients.filter((ingredient) => {
    const matchesSearch = ingredient.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || ingredient.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getIngredientQuantity = (ingredientId: string) => {
    const ingredient = selectedIngredients.find((i) => i.ingredientId === ingredientId)
    return ingredient?.quantity || 0
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ingredientes Disponibles</CardTitle>
        <div className="space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Buscar ingredientes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="capitalize"
              >
                {category === "all" ? "Todos" : category}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {filteredIngredients.map((ingredient) => {
            const quantity = getIngredientQuantity(ingredient.id)
            return (
              <div
                key={ingredient.id}
                className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="text-2xl">{ingredient.image}</div>
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      {ingredient.name}
                      {quantity > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {quantity}
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-gray-600">$0.50</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={() => onAddIngredient(ingredient)} className="shrink-0">
                    <Plus className="h-4 w-4" />
                  </Button>
                  {quantity > 0 && (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => onRemoveIngredient(ingredient.id)}
                      className="shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
