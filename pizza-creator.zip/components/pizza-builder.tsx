"use client"

import { useState } from "react"
import { PizzaCanvas } from "./pizza-canvas"
import { IngredientsPanel } from "./ingredients-panel"
import { CheckoutModal } from "./checkout-modal"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Plus, Minus } from "lucide-react"

export interface Ingredient {
  id: string
  name: string
  price: number
  category: string
  image: string
  color: string
}

export interface PizzaIngredientUnit {
  id: string
  ingredientId: string
  name: string
  price: number
  category: string
  image: string
  color: string
  position: { x: number; y: number }
  rotation: number // Agregar propiedad de rotación en grados
}

const INGREDIENTS: Ingredient[] = [
  // Base
  { id: "salsa-tomate", name: "Salsa de Tomate", price: 1.0, category: "Base", image: "🍅", color: "#DC143C" },

  // Carnes
  { id: "pepperoni", name: "Pepperoni", price: 3.5, category: "Carnes", image: "🍕", color: "#8B0000" },
  { id: "jamon", name: "Jamón", price: 3.0, category: "Carnes", image: "🥓", color: "#CD853F" },
  { id: "salchicha", name: "Salchicha", price: 3.5, category: "Carnes", image: "🌭", color: "#A0522D" },
  { id: "pollo", name: "Pollo", price: 4.0, category: "Carnes", image: "🍗", color: "#DEB887" },

  // Vegetales
  { id: "champinones", name: "Champiñones", price: 2.5, category: "Vegetales", image: "🍄", color: "#8B4513" },
  { id: "pimientos", name: "Pimientos", price: 2.0, category: "Vegetales", image: "🫑", color: "#228B22" },
  { id: "cebolla", name: "Cebolla", price: 1.5, category: "Vegetales", image: "🧅", color: "#DDA0DD" },
  { id: "tomate", name: "Tomate", price: 2.0, category: "Vegetales", image: "🍅", color: "#FF6347" },
  { id: "aceitunas", name: "Aceitunas", price: 2.5, category: "Vegetales", image: "🫒", color: "#556B2F" },

  // Quesos
  { id: "mozzarella", name: "Mozzarella Extra", price: 3.0, category: "Quesos", image: "🧀", color: "#FFFACD" },
  { id: "parmesano", name: "Parmesano", price: 3.5, category: "Quesos", image: "🧀", color: "#F5DEB3" },
  { id: "cheddar", name: "Cheddar", price: 3.0, category: "Quesos", image: "🧀", color: "#FFA500" },
]

const BASE_PRICE = 12.0

export function PizzaBuilder() {
  const [ingredientUnits, setIngredientUnits] = useState<PizzaIngredientUnit[]>([])
  const [showCheckout, setShowCheckout] = useState(false)
  const [pizzaSize, setPizzaSize] = useState<"small" | "medium" | "large">("medium")

  const sizeMultipliers = {
    small: 0.8,
    medium: 1.0,
    large: 1.3,
  }

  const addIngredient = (ingredient: Ingredient) => {
    // Generar posición aleatoria dentro del círculo de la pizza
    const angle = Math.random() * 2 * Math.PI
    const radius = Math.random() * 30 + 10 // Radio entre 10% y 40% del centro
    const centerX = 50
    const centerY = 50

    const newUnit: PizzaIngredientUnit = {
      id: `${ingredient.id}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      ingredientId: ingredient.id,
      name: ingredient.name,
      price: ingredient.price,
      category: ingredient.category,
      image: ingredient.image,
      color: ingredient.color,
      position: {
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
      },
      rotation: 0, // Inicializar rotación en 0 grados
    }

    setIngredientUnits((prev) => [...prev, newUnit])
  }

  const removeIngredientUnit = (unitId: string) => {
    setIngredientUnits((prev) => prev.filter((unit) => unit.id !== unitId))
  }

  const removeAllOfIngredient = (ingredientId: string) => {
    setIngredientUnits((prev) => prev.filter((unit) => unit.ingredientId !== ingredientId))
  }

  const calculateTotal = () => {
    const ingredientsTotal = ingredientUnits.reduce((total, unit) => {
      return total + unit.price
    }, 0)

    return (BASE_PRICE + ingredientsTotal) * sizeMultipliers[pizzaSize]
  }

  // Agrupar unidades por tipo de ingrediente para el resumen
  const groupedIngredients = ingredientUnits.reduce(
    (acc, unit) => {
      if (!acc[unit.ingredientId]) {
        acc[unit.ingredientId] = {
          ...unit,
          quantity: 1,
        }
      } else {
        acc[unit.ingredientId].quantity += 1
      }
      return acc
    },
    {} as Record<string, PizzaIngredientUnit & { quantity: number }>,
  )

  const ingredientSummary = Object.values(groupedIngredients)

  return (
    <div className="grid lg:grid-cols-3 gap-8">
      {/* Panel de Ingredientes */}
      <div className="lg:col-span-1">
        <IngredientsPanel
          ingredients={INGREDIENTS}
          onAddIngredient={addIngredient}
          onRemoveIngredient={removeAllOfIngredient}
          selectedIngredients={ingredientSummary}
        />
      </div>

      {/* Visualización de la Pizza */}
      <div className="lg:col-span-1">
        <Card className="sticky top-4">
          <CardHeader>
            <CardTitle className="text-center">Tu Pizza</CardTitle>
            <div className="flex justify-center gap-2">
              {(["small", "medium", "large"] as const).map((size) => (
                <Button
                  key={size}
                  variant={pizzaSize === size ? "default" : "outline"}
                  size="sm"
                  onClick={() => setPizzaSize(size)}
                  className="capitalize"
                >
                  {size === "small" && "Pequeña"}
                  {size === "medium" && "Mediana"}
                  {size === "large" && "Grande"}
                </Button>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            <PizzaCanvas
              ingredientUnits={ingredientUnits}
              size={pizzaSize}
              onIngredientMove={(id, position) => {
                setIngredientUnits((prev) => prev.map((unit) => (unit.id === id ? { ...unit, position } : unit)))
              }}
              onRemoveUnit={removeIngredientUnit}
              onIngredientRotate={(id, rotation) => {
                setIngredientUnits((prev) => prev.map((unit) => (unit.id === id ? { ...unit, rotation } : unit)))
              }}
            />
          </CardContent>
        </Card>
      </div>

      {/* Resumen y Checkout */}
      <div className="lg:col-span-1">
        <Card className="sticky top-4">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Resumen del Pedido
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Pizza base ({pizzaSize})</span>
                <span>${(BASE_PRICE * sizeMultipliers[pizzaSize]).toFixed(2)}</span>
              </div>

              {ingredientSummary.map((ingredient) => (
                <div key={ingredient.ingredientId} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span>{ingredient.image}</span>
                    <span>{ingredient.name}</span>
                    <Badge variant="secondary">{ingredient.quantity}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span>${(ingredient.price * ingredient.quantity).toFixed(2)}</span>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 w-6 p-0 bg-transparent"
                        onClick={() => {
                          // Encontrar y eliminar una unidad de este ingrediente
                          const unitToRemove = ingredientUnits.find(
                            (unit) => unit.ingredientId === ingredient.ingredientId,
                          )
                          if (unitToRemove) {
                            removeIngredientUnit(unitToRemove.id)
                          }
                        }}
                      >
                        <Minus className="h-3 w-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-6 w-6 p-0 bg-transparent"
                        onClick={() => {
                          const ingredientToAdd = INGREDIENTS.find((ing) => ing.id === ingredient.ingredientId)
                          if (ingredientToAdd) {
                            addIngredient(ingredientToAdd)
                          }
                        }}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>${calculateTotal().toFixed(2)}</span>
              </div>
              <p className="text-sm text-gray-600 mt-1">{ingredientUnits.length} ingredientes adicionales</p>
            </div>

            <Button
              className="w-full"
              size="lg"
              onClick={() => setShowCheckout(true)}
              disabled={ingredientUnits.length === 0}
            >
              Ordenar Pizza 🍕
            </Button>
          </CardContent>
        </Card>
      </div>

      <CheckoutModal
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
        orderSummary={{
          ingredients: ingredientSummary,
          size: pizzaSize,
          total: calculateTotal(),
          basePrice: BASE_PRICE * sizeMultipliers[pizzaSize],
        }}
      />
    </div>
  )
}
